#ifndef RECORDES
#define RECORDES

int lfbubbleSort(double *vetor, int tamanho);
void Recordes(int qtd_rec,double *tempo,int destaque);

#endif