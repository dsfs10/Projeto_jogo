#include "raylib.h"


bool isGameOver = false;//variavel

void Gameover();